export const data = [
    {
        id:1,
        imageLink: 'https://wallpaperaccess.com/full/3926232.jpg',
        username:'bryan',
        caption:'Some people feel the rain, others just get wet',
        profilePicture:'https://images.pexels.com/photos/594610/pexels-photo-594610.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'
    },
    {
        id:2,
        imageLink:'https://wallpaperaccess.com/full/2259371.jpg',
        username:'clara',
        caption:'Spring: a lovely reminder of how beautiful change can truly be',
        profilePicture:'https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'
    },
    {
        id:3,
        imageLink:'https://wallpaperaccess.com/full/2123210.jpg',
        username:'lana',
        caption:'Come fly with me',
        profilePicture:'https://images.pexels.com/photos/1987301/pexels-photo-1987301.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'
    },
    {
        id:4,
        imageLink:'https://wallpaperaccess.com/full/4004182.jpg',
        username:'charlie',
        caption:'Better to travel than to arrive',
        profilePicture:'https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'
    },
    {
        id:5,
        imageLink:'https://wallpaperaccess.com/full/1124115.jpg',
        username:'ariana',
        caption:'Okay Mother Nature, you win',
        profilePicture:'https://images.pexels.com/photos/2726111/pexels-photo-2726111.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'
    }
]